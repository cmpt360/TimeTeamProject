﻿using UnityEngine;
using System.Collections;

public static class GlobalVariables  {

	// Kill counter
	public static int kills = 0;
}
